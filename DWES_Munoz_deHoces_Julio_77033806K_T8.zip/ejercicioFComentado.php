<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        #contenedor {
            border: 2px solid black;
            border-radius: 10px;
            width: 190px;
            height: auto;
            box-shadow: 0 0 10px black;
        }

        #bandera {
            width: 150px;
            height: auto;
            padding: 20px;
            background: rgb(212, 212, 212);
            border-radius: 10px;
        }

        #resultado {
            text-align: center;
        }
    </style>
</head>

<body>
    <form id="formulario">
        Nombre del País: <input type="text" id="texto"> <br>
        <button id="boton" type="submit">Comprobar</button>
    </form>
    <div id="contenedor">
        <div id="bandera"></div>
        <div id="resultado"></div>
    </div>
</body>
<script src="js/jquery-3.7.1.min.js"></script>
<script>
    /**
    * El método ready() se ejecutará cuando toda la página carge por completo.
    *
    * @param function() Se le pasa una función que no tiene parámetro.
    * @return No devuelve nada.
    */
    $(document).ready(function () {
        /**
        * El método submit va a hacer que cuando se envie lo escrito en el formulario se va a ejecutar.
        *
        * @param function() con un parámerto e para llamar luego a la funcion preventDefault() para que no se recarge la página.
        * @return No devuleve nada.
        */
        $("#formulario").submit(function (e) {
            e.preventDefault();

            var texto = $("#texto").val();
            $.get(
                'https://restcountries.com/v3.1/name/' + texto, function (data) {
                    var pais = data[0];
                    $("#bandera").html(
                        "<img style='width:150px; height:150px' src='" + pais.coatOfArms.png + "'></img>"
                    );

                    $("#resultado").html(
                        "<p>Nombre del país: " + pais.name.common + "</p>" +
                        "<p>Iniciales: " + pais.cca3 + "</p>" +
                        "<p>Capital: " + pais.capital + "</p>" +
                        "<p>Continente: " + pais.region + "</p>" +
                        "<p>Población: " + pais.population + " personas</p>"
                    );
                }
                /**
                * El método fail() se ejecutará cuando el programa falle, en este caso cuando no encuentre la información solicitada.
                *
                * @param function() Una función sin parámertos.
                * @return No devueleve nada.
                */
            ).fail(function () {
                $("#resultado").text("ERROR: No se ha encontrado información al respecto.");
            })
        })
    })
</script>

</html>